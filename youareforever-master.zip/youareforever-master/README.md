# youareforever

#### 介绍
这是一个实现了一整套的用户与商家管理的餐饮系统

#### 软件架构
软件架构说明


#### 安装教程

1.  xxxx
2.  xxxx
3.  xxxx

#### 使用说明

使用git拉取项目,用idea打开并运行Appilcation即可运行项目，需要使用Nginx反向代理，
技术栈为SSM+Redis等，这是一个完整的可运行的项目，并巧妙地实现了个人微信小程序模拟微信支付的方法。

运行并开发此项目的过程我会逐步更新在readme文件中，也欢迎大家有运行困难，或功能实现疑问一起讨论。

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  Gitee 官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解 Gitee 上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是 Gitee 最有价值开源项目，是综合评定出的优秀开源项目
5.  Gitee 官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  Gitee 封面人物是一档用来展示 Gitee 会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
